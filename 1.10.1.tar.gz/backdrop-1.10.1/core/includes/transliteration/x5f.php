<?php

$base = array(
  0x00 => 'kai', 'bian', 'yi', 'qi', 'nong', 'fen', 'ju', 'yan', 'yi', 'zang', 'bi', 'yi', 'yi', 'er', 'san', 'shi',
  0x10 => 'er', 'shi', 'shi', 'gong', 'diao', 'yin', 'hu', 'fu', 'hong', 'wu', 'tui', 'chi', 'jiang', 'ba', 'shen', 'di',
  0x20 => 'zhang', 'jue', 'tao', 'fu', 'di', 'mi', 'xian', 'hu', 'chao', 'nu', 'jing', 'zhen', 'yi', 'mi', 'quan', 'wan',
  0x30 => 'shao', 'ruo', 'xuan', 'jing', 'diao', 'zhang', 'jiang', 'qiang', 'peng', 'dan', 'qiang', 'bi', 'bi', 'she', 'dan', 'jian',
  0x40 => 'gou', 'ge', 'fa', 'bi', 'kou', 'jian', 'bie', 'xiao', 'dan', 'guo', 'jiang', 'hong', 'mi', 'guo', 'wan', 'jue',
  0x50 => 'ji', 'ji', 'gui', 'dang', 'lu', 'lu', 'tuan', 'hui', 'zhi', 'hui', 'hui', 'yi', 'yi', 'yi', 'yi', 'yue',
  0x60 => 'yue', 'shan', 'xing', 'wen', 'tong', 'yan', 'yan', 'yu', 'chi', 'cai', 'biao', 'diao', 'bin', 'peng', 'yong', 'piao',
  0x70 => 'zhang', 'ying', 'chi', 'chi', 'zhuo', 'tuo', 'ji', 'fang', 'zhong', 'yi', 'wang', 'che', 'bi', 'di', 'ling', 'fu',
  0x80 => 'wang', 'zheng', 'cu', 'wang', 'jing', 'dai', 'xi', 'xun', 'hen', 'yang', 'huai', 'lu', 'hou', 'wang', 'cheng', 'zhi',
  0x90 => 'xu', 'jing', 'tu', 'cong', 'zhi', 'lai', 'cong', 'de', 'pai', 'xi', 'dong', 'ji', 'chang', 'zhi', 'cong', 'zhou',
  0xA0 => 'lai', 'yu', 'xie', 'jie', 'jian', 'shi', 'jia', 'bian', 'huang', 'fu', 'xun', 'wei', 'pang', 'yao', 'wei', 'xi',
  0xB0 => 'zheng', 'piao', 'ti', 'de', 'zheng', 'zheng', 'bie', 'de', 'chong', 'che', 'jiao', 'hui', 'jiao', 'hui', 'mei', 'long',
  0xC0 => 'xiang', 'bao', 'qu', 'xin', 'xin', 'bi', 'yi', 'le', 'ren', 'dao', 'ding', 'gai', 'ji', 'ren', 'ren', 'chan',
  0xD0 => 'tan', 'te', 'te', 'gan', 'qi', 'shi', 'cun', 'zhi', 'wang', 'mang', 'xi', 'fan', 'ying', 'tian', 'min', 'wen',
  0xE0 => 'zhong', 'chong', 'wu', 'ji', 'wu', 'xi', 'jia', 'you', 'wan', 'cong', 'song', 'kuai', 'yu', 'bian', 'zhi', 'qi',
  0xF0 => 'cui', 'chen', 'tai', 'tun', 'qian', 'nian', 'hun', 'xiong', 'niu', 'kuang', 'xian', 'xin', 'kang', 'hu', 'kai', 'fen',
);
